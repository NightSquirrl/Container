
import { useState, useRef } from 'react'
import Editor from '@monaco-editor/react'
import type { editor } from 'monaco-editor'
import { unzipFile } from './utils/zipUtils'

type Language = 'markdown' | 'javascript' | 'json'

const languageDefaults: Record<Language, string> = {
  markdown: `# 欢迎使用 Markdown 编辑器

## 标题

- 列表项 1
- 列表项 2
- 列表项 3

**粗体文本** 和 *斜体文本*

\`\`\`javascript
// 代码块示例
function hello() {
  console.log("Hello World!");
}
\`\`\`
`,
  javascript: `// JavaScript 编辑器
function greet(name) {
  return \`Hello, \${name}!\`;
}

const result = greet("World");
console.log(result);

// 尝试输入 'log' 或 'func' 查看代码片段
`,
  json: `{
  "name": "monaco-editor-demo",
  "version": "1.0.0",
  "description": "Monaco Editor 配置示例",
  "features": [
    "Markdown 支持",
    "JavaScript 支持",
    "JSON 支持"
  ],
  "enabled": true
}`
}

function App() {
  const [language, setLanguage] = useState<Language>('javascript')
  const [value, setValue] = useState(languageDefaults.javascript)
  const editorRef = useRef<editor.IStandaloneCodeEditor | null>(null)

  const handleEditorDidMount = (editor: editor.IStandaloneCodeEditor) => {
    editorRef.current = editor
    
    // 添加自定义代码片段
    const monaco = (window as any).monaco
    if (monaco) {
      // Markdown 代码片段
      monaco.languages.registerCompletionItemProvider('markdown', {
        provideCompletionItems: () => ({
          suggestions: [
            {
              label: 'table',
              kind: monaco.languages.CompletionItemKind.Snippet,
              insertText: '| 列1 | 列2 | 列3 |\n|-----|-----|-----|\n| 内容 | 内容 | 内容 |',
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: '插入 Markdown 表格'
            },
            {
              label: 'codeblock',
              kind: monaco.languages.CompletionItemKind.Snippet,
              insertText: '\`\`\`${1:language}\n${2:code}\n\`\`\`',
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: '插入代码块'
            },
            {
              label: 'link',
              kind: monaco.languages.CompletionItemKind.Snippet,
              insertText: '[${1:text}](${2:url})',
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: '插入链接'
            },
            {
              label: 'image',
              kind: monaco.languages.CompletionItemKind.Snippet,
              insertText: '![${1:alt}](${2:url})',
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: '插入图片'
            }
          ]
        })
      })

      // JavaScript 代码片段
      monaco.languages.registerCompletionItemProvider('javascript', {
        provideCompletionItems: () => ({
          suggestions: [
            {
              label: 'log',
              kind: monaco.languages.CompletionItemKind.Snippet,
              insertText: 'console.log(${1:message});',
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: 'Console log'
            },
            {
              label: 'func',
              kind: monaco.languages.CompletionItemKind.Snippet,
              insertText: 'function ${1:name}(${2:params}) {\n  ${3:// code}\n}',
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: 'Function declaration'
            },
            {
              label: 'arrow',
              kind: monaco.languages.CompletionItemKind.Snippet,
              insertText: 'const ${1:name} = (${2:params}) => {\n  ${3:// code}\n}',
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: 'Arrow function'
            },
            {
              label: 'for',
              kind: monaco.languages.CompletionItemKind.Snippet,
              insertText: 'for (let ${1:i} = 0; ${1:i} < ${2:length}; ${1:i}++) {\n  ${3:// code}\n}',
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: 'For loop'
            },
            {
              label: 'foreach',
              kind: monaco.languages.CompletionItemKind.Snippet,
              insertText: '${1:array}.forEach((${2:item}) => {\n  ${3:// code}\n});',
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: 'forEach loop'
            },
            {
              label: 'if',
              kind: monaco.languages.CompletionItemKind.Snippet,
              insertText: 'if (${1:condition}) {\n  ${2:// code}\n}',
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: 'If statement'
            },
            {
              label: 'try',
              kind: monaco.languages.CompletionItemKind.Snippet,
              insertText: 'try {\n  ${1:// code}\n} catch (${2:error}) {\n  ${3:// handle error}\n}',
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: 'Try-catch block'
            },
            {
              label: 'import',
              kind: monaco.languages.CompletionItemKind.Snippet,
              insertText: "import { ${1:module} } from '${2:package}';",
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: 'ES6 import'
            },
            {
              label: 'export',
              kind: monaco.languages.CompletionItemKind.Snippet,
              insertText: 'export ${1:default }${2:function} ${3:name}(${4:params}) {\n  ${5:// code}\n}',
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: 'ES6 export'
            }
          ]
        })
      })

      // JSON 代码片段
      monaco.languages.registerCompletionItemProvider('json', {
        provideCompletionItems: () => ({
          suggestions: [
            {
              label: 'obj',
              kind: monaco.languages.CompletionItemKind.Snippet,
              insertText: '"${1:key}": {\n  "${2:property}": "${3:value}"\n}',
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: 'JSON object'
            },
            {
              label: 'arr',
              kind: monaco.languages.CompletionItemKind.Snippet,
              insertText: '"${1:key}": [\n  "${2:item}"\n]',
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: 'JSON array'
            },
            {
              label: 'str',
              kind: monaco.languages.CompletionItemKind.Snippet,
              insertText: '"${1:key}": "${2:value}"',
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: 'JSON string'
            },
            {
              label: 'num',
              kind: monaco.languages.CompletionItemKind.Snippet,
              insertText: '"${1:key}": ${2:0}',
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: 'JSON number'
            },
            {
              label: 'bool',
              kind: monaco.languages.CompletionItemKind.Snippet,
              insertText: '"${1:key}": ${2|true,false|}',
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: 'JSON boolean'
            }
          ]
        })
      })
    }
  }

  const handleLanguageChange = (newLanguage: Language) => {
    setLanguage(newLanguage)
    setValue(languageDefaults[newLanguage])
  }

  const handleFormat = () => {
    if (editorRef.current) {
      editorRef.current.getAction('editor.action.formatDocument')?.run()
    }
  }

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) {
      const files = unzipFile(file);
      console.log("[ files ] >", files);
    }
  }

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
      <input id="app" type="file" onChange={handleFileChange} />
      <div style={{ 
        padding: '12px 20px', 
        background: '#1e1e1e', 
        borderBottom: '1px solid #333',
        display: 'flex',
        alignItems: 'center',
        gap: '12px'
      }}>
        <label style={{ color: '#ccc', fontSize: '14px' }}>语言:</label>
        <select 
          value={language} 
          onChange={(e) => handleLanguageChange(e.target.value as Language)}
          style={{
            padding: '6px 12px',
            background: '#2d2d2d',
            color: '#fff',
            border: '1px solid #555',
            borderRadius: '4px',
            fontSize: '14px',
            cursor: 'pointer'
          }}
        >
          <option value="javascript">JavaScript</option>
          <option value="markdown">Markdown</option>
          <option value="json">JSON</option>
        </select>
        
        <button
          onClick={handleFormat}
          style={{
            padding: '6px 16px',
            background: '#0e639c',
            color: '#fff',
            border: 'none',
            borderRadius: '4px',
            fontSize: '14px',
            cursor: 'pointer',
            marginLeft: 'auto'
          }}
        >
          格式化代码
        </button>
      </div>

      <div style={{ flex: 1, overflow: 'hidden' }}>
        <Editor
          height="100%"
          language={language}
          value={value}
          onChange={(newValue) => setValue(newValue || '')}
          onMount={handleEditorDidMount}
          theme="vs-dark"
          options={{
            minimap: { enabled: true },
            fontSize: 14,
            lineNumbers: 'on',
            roundedSelection: false,
            scrollBeyondLastLine: false,
            readOnly: false,
            automaticLayout: true,
            tabSize: 2,
            insertSpaces: true,
            wordWrap: 'on',
            formatOnPaste: true,
            formatOnType: true,
            suggestOnTriggerCharacters: true,
            quickSuggestions: {
              other: true,
              comments: true,
              strings: true
            },
            snippetSuggestions: 'top'
          }}
        />
      </div>
    </div>
  )
}

export default App
