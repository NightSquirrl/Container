import JSZip from 'jszip';

export interface UnzippedFile {
  name: string;
  content: string | Uint8Array;
  isText: boolean;
}

export interface UnzipResult {
  success: boolean;
  files: UnzippedFile[];
  error?: string;
}

/**
 * 解压 ZIP 文件
 * @param file - ZIP 文件对象或 ArrayBuffer
 * @returns 解压结果，包含文件列表
 */
export async function unzipFile(file: File | ArrayBuffer): Promise<UnzipResult> {
  try {
    const zip = new JSZip();
    
    // 加载 ZIP 文件
    let content: ArrayBuffer;
    if (file instanceof File) {
      content = await file.arrayBuffer();
    } else {
      content = file;
    }
    
    const loadedZip = await zip.loadAsync(content);
    const files: UnzippedFile[] = [];
    
    // 遍历 ZIP 中的所有文件
    const filePromises: Promise<void>[] = [];
    
    loadedZip.forEach((relativePath, zipEntry) => {
      if (!zipEntry.dir) {
        const promise = (async () => {
          // 尝试以文本格式读取
          const textContent = await zipEntry.async('string').catch(() => null);
          
          if (textContent !== null) {
            // 检查是否是文本文件（简单判断：没有乱码字符）
            const isText = !/[^\x20-\x7E\s\u4e00-\u9fa5]/.test(textContent.slice(0, 1000));
            
            if (isText) {
              files.push({
                name: relativePath,
                content: textContent,
                isText: true
              });
            } else {
              // 二进制文件
              const binaryContent = await zipEntry.async('uint8array');
              files.push({
                name: relativePath,
                content: binaryContent,
                isText: false
              });
            }
          } else {
            // 无法作为文本读取，使用二进制
            const binaryContent = await zipEntry.async('uint8array');
            files.push({
              name: relativePath,
              content: binaryContent,
              isText: false
            });
          }
        })();
        
        filePromises.push(promise);
      }
    });
    
    await Promise.all(filePromises);
    
    return {
      success: true,
      files
    };
  } catch (error) {
    return {
      success: false,
      files: [],
      error: error instanceof Error ? error.message : '解压失败'
    };
  }
}


/**
 * 获取 ZIP 文件中的特定文件
 * @param file - ZIP 文件对象或 ArrayBuffer
 * @param fileName - 要查找的文件名（支持模糊匹配）
 * @returns 找到的文件内容，如果没找到返回 null
 */
export async function getFileFromZip(
  file: File | ArrayBuffer, 
  fileName: string
): Promise<UnzippedFile | null> {
  const result = await unzipFile(file);
  
  if (!result.success) {
    return null;
  }
  
  // 精确匹配
  let found = result.files.find(f => f.name === fileName);
  
  // 模糊匹配（文件名包含）
  if (!found) {
    found = result.files.find(f => f.name.includes(fileName));
  }
  
  return found || null;
}
