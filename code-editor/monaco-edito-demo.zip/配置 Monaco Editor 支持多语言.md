# 配置 Monaco Editor 支持多语言

> **Workspace:** e:\code\monaco-edito-demo

---

## User
帮我在当前项目中配置一下monaco-edito 该如何使用,需要支持markdown javascirpt json 三种语言的编辑和快捷输入

## Assistant
依赖安装完成。现在我来配置 Monaco Editor 组件，支持 Markdown、JavaScript 和 JSON 三种语言的编辑和快捷输入。

现在需要更新全局样式，确保编辑器占满整个视口：

项目已成功启动！让我更新任务状态并为你打开预览：

Monaco Editor 配置完成！项目已运行在 http://localhost:5175/

## 配置说明

### 已安装依赖
- `@monaco-editor/react` - React 封装的 Monaco Editor 组件
- `monaco-editor` - Monaco Editor 核心库

### 功能特性

**1. 语言切换**
- 顶部下拉菜单可切换 JavaScript / Markdown / JSON
- 切换时自动加载对应语言的示例代码

**2. 快捷输入代码片段 (Snippets)**

| 语言 | 快捷输入 | 功能 |
|------|----------|------|
| JavaScript | `log` | console.log |
| | `func` | 函数声明 |
| | `arrow` | 箭头函数 |
| | `for` | for 循环 |
| | `foreach` | forEach 循环 |
| | `if` | if 语句 |
| | `try` | try-catch |
| | `import` | ES6 导入 |
| | `export` | ES6 导出 |
| Markdown | `table` | 插入表格 |
| | `codeblock` | 插入代码块 |
| | `link` | 插入链接 |
| | `image` | 插入图片 |
| JSON | `obj` | JSON 对象 |
| | `arr` | JSON 数组 |
| | `str` | JSON 字符串 |
| | `num` | JSON 数字 |
| | `bool` | JSON 布尔值 |

**3. 编辑器配置**
- 深色主题 (`vs-dark`)
- 自动格式化
- 代码补全
- 小地图 (minimap)
- 自动换行

你可以在编辑器中输入快捷代码片段（如输入 `log` 后按 Tab），体验代码自动补全功能！

