<template>
  <div class="tool-part" :style="{ borderLeftColor: accentColor }">
    <!-- Header -->
    <div class="tool-header" @click="open = !open">
      <span class="state-icon" :style="{ color: accentColor, animationPlayState: isRunning ? 'running' : 'paused' }">
        {{ stateIcon }}
      </span>
      <span class="tool-name">{{ part.tool }}</span>
      <span v-if="part.callID" class="call-id">#{{ part.callID }}</span>
      <span v-if="dur" class="dur">{{ dur }}</span>
      <span v-if="isTodo && todos" class="todo-count">{{ todos.length }} tasks</span>
      <span class="chevron">{{ open ? '▲' : '▼' }}</span>
    </div>

    <!-- Todo list (inline, always visible) -->
    <div v-if="isTodo && todos" class="todo-list">
      <div v-for="(todo, i) in todos" :key="i" class="todo-item">
        <span class="todo-icon" :style="{ color: todoColor(todo.status) }">
          {{ todoIcon(todo.status) }}
        </span>
        <span class="todo-content" :class="todo.status">{{ todo.content }}</span>
        <span v-if="todo.priority === 'high'" class="priority-badge">HIGH</span>
      </div>
    </div>

    <!-- Generic expand: input / output -->
    <div v-if="open && !isTodo" class="tool-body">
      <div v-if="state?.input" class="section">
        <div class="section-label">INPUT</div>
        <pre class="section-content input-pre">{{ JSON.stringify(state.input, null, 2) }}</pre>
      </div>
      <div v-if="state?.output" class="section">
        <div class="section-label">OUTPUT</div>
        <pre class="section-content output-pre">{{ typeof state.output === 'string' ? state.output : JSON.stringify(state.output, null, 2) }}</pre>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { fmtDuration } from '../../utils/fmt.js'

const props = defineProps({ part: { type: Object, required: true } })

const open  = ref(false)
const state = computed(() => props.part.state)

const isRunning    = computed(() => !state.value?.status || state.value.status === 'running')
const isError      = computed(() => state.value?.status === 'error')
const accentColor  = computed(() => isRunning.value ? '#f59e0b' : isError.value ? '#ef4444' : '#22c55e')
const stateIcon    = computed(() => isRunning.value ? '⟳' : isError.value ? '✗' : '✓')
const dur          = computed(() => fmtDuration(state.value?.time?.start, state.value?.time?.end))
const isTodo       = computed(() => props.part.tool === 'todowrite')
const todos        = computed(() => state.value?.metadata?.todos || state.value?.input?.todos)

const TODO_ICONS  = { completed: '✓', in_progress: '◉', pending: '○' }
const TODO_COLORS = { completed: '#22c55e', in_progress: '#f59e0b', pending: '#343460' }
const todoIcon  = (s) => TODO_ICONS[s]  || '○'
const todoColor = (s) => TODO_COLORS[s] || '#343460'
</script>

<style scoped>
.tool-part {
  margin: 4px 0;
  border-radius: 8px;
  border: 1px solid var(--border);
  border-left-width: 3px;
  background: var(--bg-card);
  font-family: var(--mono);
  font-size: 12px;
  overflow: hidden;
}

.tool-header {
  display: flex; align-items: center; gap: 8px;
  padding: 8px 12px; cursor: pointer; user-select: none;
}
.state-icon {
  font-size: 13px;
  display: inline-block;
  animation: spin 1.2s linear infinite;
}
.tool-name  { color: var(--blue); font-weight: 700; }
.call-id    { color: var(--text-dim); }
.dur        { color: var(--text-dim); }
.todo-count { color: var(--purple); }
.chevron    { margin-left: auto; color: var(--text-dim); font-size: 10px; }

/* Todo list */
.todo-list { padding: 0 14px 10px; display: flex; flex-direction: column; gap: 6px; }
.todo-item { display: flex; align-items: center; gap: 8px; }
.todo-icon { width: 14px; flex-shrink: 0; }
.todo-content { flex: 1; font-size: 13px; color: var(--text-primary); font-family: inherit; }
.todo-content.completed { color: var(--text-dim); text-decoration: line-through; }
.priority-badge {
  font-size: 9px; color: var(--red);
  background: #1a0606; border: 1px solid #3a0a0a;
  padding: 1px 5px; border-radius: 3px; flex-shrink: 0;
}

/* Generic body */
.tool-body { border-top: 1px solid var(--border-dim); padding: 10px 14px; }
.section { margin-bottom: 10px; }
.section:last-child { margin-bottom: 0; }
.section-label { color: var(--text-dim); font-size: 10px; letter-spacing: 1px; margin-bottom: 4px; }
.section-content {
  margin: 0; font-size: 11px;
  white-space: pre-wrap; word-break: break-all;
}
.input-pre  { color: #80c060; }
.output-pre { color: var(--text-second); max-height: 240px; overflow: auto; }
</style>
