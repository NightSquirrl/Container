<template>
  <div class="step-start">
    <div class="line" />
    <span>step</span>
    <div class="line" />
  </div>
</template>

<style scoped>
.step-start {
  display: flex; align-items: center; gap: 8px;
  margin: 10px 0 4px;
  color: var(--text-dim); font-size: 10px;
  font-family: var(--mono);
}
.line { flex: 1; height: 1px; background: var(--border-dim); }
</style>
