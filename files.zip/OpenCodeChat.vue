<template>
  <div class="app">
    <!-- ── Header ── -->
    <header class="header">
      <div class="header-logo">
        <span class="logo-text">opencode</span>
        <span class="session-id">{{ sessionID.slice(0, 24) }}…</span>
      </div>

      <button
        v-for="t in ['chat', 'raw']"
        :key="t"
        class="tab-btn"
        :class="{ active: tab === t }"
        @click="tab = t"
      >
        {{ t === 'chat' ? 'Chat' : 'Raw JSON' }}
      </button>

      <div class="header-right">
        <span class="model-badge">kimi-k2.5</span>
        <span class="status-dot" />
      </div>
    </header>

    <!-- ── Body ── -->
    <main class="body">
      <pre v-if="tab === 'raw'" class="raw-json">{{ JSON.stringify(REAL_DATA, null, 2) }}</pre>

      <div v-else class="messages-wrap">
        <MessageBubble
          v-for="msg in REAL_DATA"
          :key="msg.info.id"
          :message="msg"
        />
      </div>
    </main>

    <!-- ── Input bar ── -->
    <footer class="footer">
      <div class="input-fake">发送消息…</div>
      <button class="send-btn">发送</button>
    </footer>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import MessageBubble from './MessageBubble.vue'

const tab = ref('chat')

const REAL_DATA = [
  {
    info: {
      role: 'user',
      time: { created: 1773133412182 },
      summary: { diffs: [] },
      agent: 'build',
      model: { providerID: 'moonshotai-cn', modelID: 'kimi-k2.5' },
      id: 'msg_0rbVmCNj0000aSYXhTGwcs',
      sessionID: 'ses_32904daa7ffev4AOVxvhwQfueJ',
    },
    parts: [
      {
        type: 'text',
        text: '使用theme-script-creator 技能和 script-create-output-format 技能完成下方的任务',
        id: 'prt_cd6fcb756001HxQOPRqFkezHOm',
        sessionID: 'ses_32904daa7ffev4AOVxvhwQfueJ',
        messageID: 'msg_0rbVmCNj0000aSYXhTGwcs',
      },
      {
        type: 'text',
        text: '[{"name":"bg","width":1080,"height":2400,"x":0,"y":0,"visibility":true},{"name":"dl_0","width":650,"height":48,"x":250,"y":455,"visibility":true,"description":"按照电量实时变化切换展示图路径_后面的值，除以5后不带小数点，例如电量97除以5等于19.4，去掉小数点后为19，则展示dl_19.png"},{"name":"week_0","width":138,"height":47,"x":558,"y":569,"visibility":true},{"name":"sj_0","width":139,"height":201,"x":180,"y":215,"visibility":true},{"name":"sj_0","width":139,"height":201,"x":344,"y":215,"visibility":true},{"name":"sj_0","width":139,"height":201,"x":595,"y":215,"visibility":true},{"name":"sj_0","width":139,"height":201,"x":759,"y":215,"visibility":true},{"name":"icon","width":41,"height":72,"x":180,"y":443,"visibility":true},{"name":"light_0","width":61,"height":81,"x":66,"y":2260,"visibility":true},{"name":"camera","width":86,"height":69,"x":930,"y":2267,"visibility":true},{"name":"eye_b","width":117,"height":74,"x":824,"y":1481,"visibility":true},{"name":"eye_c","width":148,"height":33,"x":540,"y":1689,"visibility":true},{"name":"glass_c","width":212,"height":102,"x":539,"y":1722,"visibility":true},{"name":"sj_maohao","width":38,"height":148,"x":520,"y":253,"visibility":true},{"name":"yue_1","width":80,"height":42,"x":327,"y":571,"visibility":true},{"name":"day_0","width":28,"height":41,"x":417,"y":572,"visibility":true},{"name":"eye_g","width":108,"height":54,"x":167,"y":1397,"visibility":true},{"name":"day_0","width":28,"height":41,"x":455,"y":572,"visibility":true},{"name":"eye_w","width":98,"height":52,"x":167,"y":968,"visibility":true},{"name":"weatherType2_0","width":72,"height":72,"x":812,"y":556,"visibility":true,"description":"按照天气实时变化切换展示图路径_后面的值"},{"name":"eye_z","width":88,"height":33,"x":856,"y":978,"visibility":true}]',
        id: 'prt_cd6fcb7560027AH0pz82XkUA7q',
        sessionID: 'ses_32904daa7ffev4AOVxvhwQfueJ',
        messageID: 'msg_0rbVmCNj0000aSYXhTGwcs',
      },
      {
        type: 'text',
        text: '将上述JSON数据,生成直板机锁屏的xml脚本',
        id: 'prt_cd6fcb756003Ohz0L95VCmJ3Sy',
        sessionID: 'ses_32904daa7ffev4AOVxvhwQfueJ',
        messageID: 'msg_0rbVmCNj0000aSYXhTGwcs',
      },
    ],
  },
  {
    info: {
      role: 'assistant',
      time: { created: 1773133418037, completed: 1773133425318 },
      parentID: 'msg_0rbVmCNj0000aSYXhTGwcs',
      modelID: 'kimi-k2.5',
      providerID: 'moonshotai-cn',
      mode: 'build',
      agent: 'build',
      path: { cwd: 'C:\\Users\\y60034093', root: '/' },
      cost: 0,
      tokens: {
        total: 14930,
        input: 3692,
        output: 230,
        reasoning: 0,
        cache: { read: 11008, write: 0 },
      },
      finish: 'tool-calls',
      id: 'msg_cd6fcce35001HplRPBVvoDpi7e',
      sessionID: 'ses_32904daa7ffev4AOVxvhwQfueJ',
    },
    parts: [
      {
        type: 'step-start',
        id: 'prt_cd6fcdbb70010GVNSoZkkVfz6i',
        sessionID: 'ses_32904daa7ffev4AOVxvhwQfueJ',
        messageID: 'msg_cd6fcce35001HplRPBVvoDpi7e',
      },
      {
        type: 'reasoning',
        text: '用户要求生成一个直板机锁屏的XML脚本，根据提供的JSON数据。根据技能要求，我需要按照7个步骤来执行：\n\n1. 获取基础信息\n2. 检查缺失信息\n3. 读取参考文档\n4. 检查元素属性\n5. 检查错误示例\n6. 生成XML脚本\n7. 验证和输出\n\n让我先创建TODO列表，然后开始执行。',
        time: { start: 1773133421499, end: 1773133425303 },
        id: 'prt_cd6fcdbbb001tEyn83r1UwLJ5U',
        sessionID: 'ses_32904daa7ffev4AOVxvhwQfueJ',
        messageID: 'msg_cd6fcce35001HplRPBVvoDpi7e',
      },
      {
        type: 'text',
        text: '我将按照技能要求完成这个任务。首先创建任务列表：',
        time: { start: 1773133425304, end: 1773133425304 },
        id: 'prt_cd6fce06e001cSX55dw4rYfMzB',
        sessionID: 'ses_32904daa7ffev4AOVxvhwQfueJ',
        messageID: 'msg_cd6fcce35001HplRPBVvoDpi7e',
      },
      {
        type: 'tool',
        callID: 'todowrite:2',
        tool: 'todowrite',
        state: {
          status: 'completed',
          input: {
            todos: [
              { content: '获取基础信息：模块、设备、分辨率', status: 'in_progress', priority: 'high' },
              { content: '检查缺失信息', status: 'pending', priority: 'high' },
              { content: '读取参考文档', status: 'pending', priority: 'high' },
              { content: '检查元素属性', status: 'pending', priority: 'high' },
              { content: '检查precautions.md中的错误示例', status: 'pending', priority: 'high' },
              { content: '生成XML脚本', status: 'pending', priority: 'high' },
              { content: '验证并输出', status: 'pending', priority: 'high' },
            ],
          },
          output:
            '[\n  {\n    "content": "获取基础信息：模块、设备、分辨率",\n    "status": "in_progress",\n    "priority": "high"\n  },\n  {\n    "content": "检查缺失信息",\n    "status": "pending",\n    "priority": "high"\n  },\n  {\n    "content": "读取参考文档",\n    "status": "pending",\n    "priority": "high"\n  },\n  {\n    "content": "检查元素属性",\n    "status": "pending",\n    "priority": "high"\n  },\n  {\n    "content": "检查precautions.md中的错误示例",\n    "status": "pending",\n    "priority": "high"\n  },\n  {\n    "content": "生成XML脚本",\n    "status": "pending",\n    "priority": "high"\n  },\n  {\n    "content": "验证并输出",\n    "status": "pending",\n    "priority": "high"\n  }\n]',
          title: '7 todos',
          metadata: {
            todos: [
              { content: '获取基础信息：模块、设备、分辨率', status: 'in_progress', priority: 'high' },
              { content: '检查缺失信息', status: 'pending', priority: 'high' },
              { content: '读取参考文档', status: 'pending', priority: 'high' },
              { content: '检查元素属性', status: 'pending', priority: 'high' },
              { content: '检查precautions.md中的错误示例', status: 'pending', priority: 'high' },
              { content: '生成XML脚本', status: 'pending', priority: 'high' },
              { content: '验证并输出', status: 'pending', priority: 'high' },
            ],
            truncated: false,
          },
          time: { start: 1773133425298, end: 1773133425300 },
        },
        id: 'prt_cd6fce1bd001ZmEeOE6iPNMq4G',
        sessionID: 'ses_32904daa7ffev4AOVxvhwQfueJ',
        messageID: 'msg_cd6fcce35001HplRPBVvoDpi7e',
      },
      {
        type: 'step-finish',
        reason: 'tool-calls',
        cost: 0,
        tokens: { total: 14930, input: 3692, output: 230, reasoning: 0, cache: { read: 11008, write: 0 } },
        id: 'prt_cd6fcea9a001yi7UpBPRB70M6o',
        sessionID: 'ses_32904daa7ffev4AOVxvhwQfueJ',
        messageID: 'msg_cd6fcce35001HplRPBVvoDpi7e',
      },
    ],
  },
]

const sessionID = REAL_DATA[0]?.info?.sessionID || ''
</script>

<style>
/* ── Global reset & tokens ── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
:root {
  --bg:          #07071a;
  --bg-deep:     #04040f;
  --bg-card:     #0b0b22;
  --border:      #14142e;
  --border-dim:  #0c0c22;
  --text-primary:#d0d0e8;
  --text-second: #7878a0;
  --text-dim:    #343460;
  --purple:      #7c5cfc;
  --purple-dim:  #3a2870;
  --blue:        #3b9eff;
  --blue-dim:    #0c2a4a;
  --green:       #22c55e;
  --amber:       #f59e0b;
  --red:         #ef4444;
  --teal:        #14b8a6;
  --mono:        'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace;
}
@keyframes spin    { to { transform: rotate(360deg); } }
@keyframes fadeIn  { from { opacity:0; transform:translateY(5px); } to { opacity:1; transform:none; } }
::-webkit-scrollbar { width: 4px; height: 4px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: #1c1c38; border-radius: 2px; }
button:focus { outline: none; }
</style>

<style scoped>
.app {
  min-height: 100vh;
  background: var(--bg);
  display: flex;
  flex-direction: column;
  font-family: 'Segoe UI', system-ui, sans-serif;
  color: var(--text-primary);
}

/* ── Header ── */
.header {
  display: flex;
  align-items: center;
  padding: 0 20px;
  min-height: 48px;
  background: var(--bg-deep);
  border-bottom: 1px solid var(--border-dim);
  gap: 0;
}
.header-logo { margin-right: 24px; display: flex; align-items: center; gap: 8px; }
.logo-text   { font-size: 13px; font-weight: 700; color: var(--purple); letter-spacing: 0.5px; }
.session-id  { font-size: 11px; color: var(--text-dim); font-family: var(--mono); }

.tab-btn {
  background: none; border: none; cursor: pointer;
  padding: 14px; font-size: 12px;
  color: var(--text-dim);
  border-bottom: 2px solid transparent;
  transition: color .15s;
}
.tab-btn.active { color: var(--purple); border-bottom-color: var(--purple); }

.header-right { margin-left: auto; display: flex; align-items: center; gap: 8px; }
.model-badge {
  font-size: 11px; color: var(--blue);
  background: var(--blue-dim); border: 1px solid #0a2040;
  padding: 2px 8px; border-radius: 4px; font-family: var(--mono);
}
.status-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--green); }

/* ── Body ── */
.body { flex: 1; overflow: auto; padding: 24px 20px; }
.raw-json {
  font-size: 11px; color: #38386a;
  font-family: var(--mono);
  white-space: pre-wrap; word-break: break-all; line-height: 1.6;
}
.messages-wrap { max-width: 820px; margin: 0 auto; }

/* ── Footer ── */
.footer {
  display: flex; gap: 10px; align-items: center;
  padding: 10px 20px;
  border-top: 1px solid var(--border-dim);
  background: var(--bg-deep);
}
.input-fake {
  flex: 1; background: var(--bg-card);
  border: 1px solid var(--border); border-radius: 8px;
  padding: 9px 14px; font-size: 13px; color: var(--text-dim);
}
.send-btn {
  background: linear-gradient(135deg, var(--purple), #5b21b6);
  border: none; border-radius: 8px;
  color: #fff; font-size: 13px; font-weight: 600;
  padding: 9px 20px; cursor: pointer;
  box-shadow: 0 0 16px #7c5cfc28;
}
</style>
