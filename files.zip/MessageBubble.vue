<template>
  <div class="message" :class="isUser ? 'user' : 'assistant'">
    <!-- Avatar -->
    <div class="avatar" :class="isUser ? 'avatar-user' : 'avatar-ai'">
      {{ isUser ? 'U' : 'AI' }}
    </div>

    <!-- Bubble -->
    <div class="bubble" :class="{ 'bubble-user': isUser }">
      <!-- Meta row -->
      <div class="meta">
        <span class="meta-role" :class="isUser ? 'role-user' : 'role-ai'">{{ info.role }}</span>
        <span v-if="modelLabel" class="meta-item">{{ modelLabel }}</span>
        <span v-if="info.agent" class="meta-item">· {{ info.agent }}</span>
        <span v-if="info.providerID && !isUser" class="meta-item meta-dim">· {{ info.providerID }}</span>
        <span class="meta-time">{{ fmtTime(info.time?.created) }}</span>
      </div>

      <!-- Parts -->
      <div class="parts">
        <template v-for="part in parts" :key="part.id">
          <TextPart      v-if="part.type === 'text'"        :part="part" />
          <ReasoningPart v-else-if="part.type === 'reasoning'"   :part="part" />
          <ToolPart      v-else-if="part.type === 'tool'"        :part="part" />
          <StepStart     v-else-if="part.type === 'step-start'" />
          <StepFinish    v-else-if="part.type === 'step-finish'" :part="part" />
        </template>
      </div>

      <!-- Token footer (assistant only) -->
      <div v-if="!isUser && info.tokens" class="token-footer">
        <span>total {{ info.tokens.total?.toLocaleString() }}</span>
        <span>↑ {{ info.tokens.input }}</span>
        <span>↓ {{ info.tokens.output }}</span>
        <span v-if="info.tokens.cache?.read > 0" class="cache-stat">
          ⚡ {{ info.tokens.cache.read?.toLocaleString() }}
        </span>
        <span v-if="elapsed">⏱ {{ elapsed }}</span>
        <span v-if="info.finish" class="finish-reason">· {{ info.finish }}</span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import TextPart      from './parts/TextPart.vue'
import ReasoningPart from './parts/ReasoningPart.vue'
import ToolPart      from './parts/ToolPart.vue'
import StepStart     from './parts/StepStart.vue'
import StepFinish    from './parts/StepFinish.vue'
import { fmtTime, fmtDuration } from '../utils/fmt.js'

const props = defineProps({
  message: { type: Object, required: true },
})

const info     = computed(() => props.message.info)
const parts    = computed(() => props.message.parts)
const isUser   = computed(() => info.value.role === 'user')
const modelLabel = computed(() => info.value.modelID || info.value.model?.modelID || '')
const elapsed  = computed(() => fmtDuration(info.value.time?.created, info.value.time?.completed))
</script>

<style scoped>
.message {
  display: flex;
  gap: 10px;
  margin-bottom: 28px;
  align-items: flex-start;
  animation: fadeIn .2s ease;
}
.message.user { flex-direction: row-reverse; }

/* Avatar */
.avatar {
  width: 30px; height: 30px; border-radius: 50%;
  flex-shrink: 0; margin-top: 2px;
  display: flex; align-items: center; justify-content: center;
  font-size: 11px; font-weight: 800; color: #fff;
}
.avatar-user { background: linear-gradient(135deg, #6d28d9, #8b5cf6); box-shadow: 0 0 12px #6d28d930; }
.avatar-ai   { background: linear-gradient(135deg, #0c4a6e, #0369a1); box-shadow: 0 0 12px #0369a130; }

/* Bubble */
.bubble { flex: 1; }
.bubble-user {
  max-width: 80%;
  background: #0c0a24;
  border: 1px solid #1c1840;
  border-radius: 10px;
  padding: 10px 14px;
}

/* Meta */
.meta {
  display: flex; align-items: center; flex-wrap: wrap; gap: 6px;
  margin-bottom: 8px;
  font-size: 11px; color: var(--text-dim); font-family: var(--mono);
}
.meta-role   { font-weight: 600; }
.role-user   { color: #8b5cf6; }
.role-ai     { color: var(--blue); }
.meta-item   { color: var(--text-dim); }
.meta-dim    { color: #1a2a3a; }
.meta-time   { margin-left: auto; }

/* Parts */
.parts { display: flex; flex-direction: column; gap: 2px; }

/* Token footer */
.token-footer {
  display: flex; flex-wrap: wrap; gap: 12px;
  margin-top: 10px; padding-top: 8px;
  border-top: 1px solid var(--border-dim);
  font-size: 11px; color: var(--text-dim);
  font-family: var(--mono);
}
.cache-stat    { color: #1a3a28; }
.finish-reason { color: #1a1a38; }
</style>
