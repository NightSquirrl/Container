<template>
  <div v-if="t" class="step-finish">
    <span>↑ {{ t.input?.toLocaleString() }} in</span>
    <span>↓ {{ t.output?.toLocaleString() }} out</span>
    <span v-if="t.reasoning > 0">💭 {{ t.reasoning }}</span>
    <span v-if="t.cache?.read > 0" class="cache">⚡ {{ t.cache.read?.toLocaleString() }} cached</span>
    <span class="reason">· {{ part.reason }}</span>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({ part: { type: Object, required: true } })
const t = computed(() => props.part.tokens)
</script>

<style scoped>
.step-finish {
  display: flex; flex-wrap: wrap; gap: 10px;
  margin: 4px 0 10px;
  font-size: 11px; color: var(--text-dim);
  font-family: var(--mono);
}
.cache  { color: #1a3a2a; }
.reason { color: #1a1a38; }
</style>
