<template>
  <div class="reasoning">
    <button class="toggle" @click="open = !open">
      <span class="arrow" :class="{ rotated: open }">▶</span>
      <span class="label">思考过程</span>
      <span v-if="dur" class="dur">{{ dur }}</span>
      <span v-if="!open && preview" class="preview">{{ preview }}…</span>
    </button>
    <div v-if="open" class="content">{{ part.text }}</div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { fmtDuration } from '../../utils/fmt.js'

const props = defineProps({ part: { type: Object, required: true } })

const open    = ref(false)
const dur     = computed(() => fmtDuration(props.part.time?.start, props.part.time?.end))
const preview = computed(() => props.part.text?.replace(/\n/g, ' ').slice(0, 60))
</script>

<style scoped>
.reasoning { margin: 2px 0; }

.toggle {
  all: unset; cursor: pointer;
  display: flex; align-items: center; gap: 6px; padding: 3px 0;
}
.arrow {
  color: var(--purple); font-size: 9px;
  display: inline-block;
  transition: transform .15s;
}
.arrow.rotated { transform: rotate(90deg); }
.label   { color: var(--purple); font-size: 12px; }
.dur     { color: var(--text-dim); font-size: 11px; font-family: var(--mono); }
.preview { color: var(--text-dim); font-size: 11px; font-style: italic; }

.content {
  margin-top: 4px;
  border-left: 2px solid var(--purple-dim);
  padding-left: 12px; margin-left: 3px;
  color: var(--text-second); font-size: 12px;
  font-family: var(--mono); line-height: 1.75;
  white-space: pre-wrap;
}
</style>
