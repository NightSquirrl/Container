<template>
  <!-- JSON text → collapsible block -->
  <div v-if="parsed" class="json-block">
    <div class="json-header" @click="open = !open">
      <span class="json-icon">{ }</span>
      <span class="json-label">{{ jsonLabel }}</span>
      <span class="chevron">{{ open ? '▲' : '▼' }}</span>
    </div>
    <div v-if="open" class="json-body">
      <pre>{{ JSON.stringify(parsed, null, 2) }}</pre>
    </div>
  </div>

  <!-- Plain text -->
  <div v-else class="text-content">
    <template v-for="(line, i) in lines" :key="i">
      <div v-if="line === ''" class="line-gap" />
      <div v-else-if="isBullet(line)" class="line-bullet">
        <span class="bullet-dot">•</span>
        <span v-html="renderInline(line.replace(/^[-•]\s/, ''))"></span>
      </div>
      <div v-else-if="isOrdered(line)" class="line-bullet">
        <span class="bullet-dot">{{ line.match(/^\d+/)[0] }}.</span>
        <span v-html="renderInline(line.replace(/^\d+\.\s/, ''))"></span>
      </div>
      <div v-else v-html="renderInline(line)" />
    </template>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { tryJSON } from '../../utils/fmt.js'

const props = defineProps({ part: { type: Object, required: true } })

const open   = ref(false)
const parsed = computed(() => tryJSON(props.part.text))

const jsonLabel = computed(() => {
  if (!parsed.value) return ''
  return Array.isArray(parsed.value)
    ? `JSON 数组 · ${parsed.value.length} 项`
    : `JSON 对象 · ${Object.keys(parsed.value).length} 字段`
})

const lines = computed(() => (props.part.text || '').split('\n'))

function isBullet(line) { return /^[-•]\s/.test(line) }
function isOrdered(line) { return /^\d+\.\s/.test(line) }

// convert **bold** to <strong>
function renderInline(text) {
  return text.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
}
</script>

<style scoped>
/* JSON block */
.json-block {
  margin: 4px 0;
  border-radius: 8px;
  border: 1px solid var(--border);
  border-left: 3px solid var(--teal);
  background: var(--bg-card);
  font-family: var(--mono);
  font-size: 12px;
  overflow: hidden;
}
.json-header {
  display: flex; align-items: center; gap: 8px;
  padding: 8px 12px; cursor: pointer; user-select: none;
}
.json-icon  { color: var(--teal); }
.json-label { color: var(--text-second); flex: 1; }
.chevron    { color: var(--text-dim); font-size: 10px; }
.json-body  { border-top: 1px solid var(--border-dim); padding: 10px 14px; }
.json-body pre {
  margin: 0; color: #60a8d0; font-size: 11px;
  white-space: pre-wrap; word-break: break-all;
  max-height: 320px; overflow: auto;
}

/* Plain text */
.text-content { color: var(--text-primary); font-size: 14px; line-height: 1.8; }
.line-gap     { height: 4px; }
.line-bullet  { display: flex; gap: 8px; margin-left: 8px; }
.bullet-dot   { color: var(--purple); flex-shrink: 0; margin-top: 1px; font-family: var(--mono); font-size: 12px; }

:deep(strong) { color: #fff; font-weight: 600; }
</style>
